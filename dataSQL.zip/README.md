# SQL Analytics Project

Hi :) 
This might seem as a boring or simplistic SQL project but I wanted to give a more realistic perspective on what I think an SQL Junior is actually using in 
matter of syntax for his/her job. I do love SQL (was my favourite course from university, btw) and I would be very glad to learn more and grow in this area.

The queries you will see are based on the day-to-day needs at my current job, when from time to time, I need to use SQL queries in order to extract some information about the players, or just to quickly check a potential bug when receiving cusommer support inquiries.

This project is more about reflecting my current SQL level, what I understand and what I know to apply, and for sure this could be just a small drop of a big ocean to come in matter of learning and self developing. The current job is limitated when it comes to SQL and for me, this will be the ideal leap of my career: to study and learn more SQL at a "real job", with "real SQL". xdd and btw: thanks for reading all of this, and thanks for your time anyway.

-- 📁 Project Structure

- `queries/` – Real-life SQL use cases (split by topic)
- `reports/` – Raw notes or additional insights
- `data/` – Synthetic game data (users, sessions, purchases, spins)



-- 🔢 Sample Data

- `users.csv` – Player info
- `sessions.csv` – Session logs
- `purchases.csv` – In-app transactions
- `spins.csv` – Gameplay behavior