/* Reporting all the mailers received by email for a specific player identified by his email */
SELECT time_stamp, *
FROM hof_ng.hof_str_email_analytics
WHERE user_email = 'example@email.com'
    AND event_date >= '2025-01-01'
ORDER BY time_stamp DESC


/* Reporting all the mailers sent by email to a specific player identified by his user id */
SELECT *
FROM hof_ng.hof_str_email_analytics
WHERE uid = 183910735
    AND event_date >= '2024-02-01'
    AND action_type = 'send'
ORDER BY time_stamp DESC


/* Verifying the total reach of a specific campaign sent by email */
SELECT COUNT(DISTINCT uid)
FROM hof_str_email_analytics
WHERE mailing_name IN ('[Email - FB] Scapes 190625')


/* Email update events */
SELECT time_stamp, *
FROM hof_ng.hof_str_event_email_collect_tracking
WHERE uid = 170418534
    AND event_date >= '2024-01-01'
ORDER BY time_stamp DESC
