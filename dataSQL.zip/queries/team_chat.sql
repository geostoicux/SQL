/* Chat messages containing a specific keyword
 Searches all team chat logs for messages that include the keyword 'win3947' */
 
SELECT *
FROM hof_ng.hof_str_event_hof_team_up_chat_messages
WHERE message LIKE '%win%3947%'
ORDER BY time_stamp DESC
