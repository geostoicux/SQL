/* Fun Machine activity
 Fetches all tracked activity in the F. S. Machine for a specific user after a certain date */
SELECT *
FROM hof_ng.hof_str_event_hof_fun_slot_machine_tracking
WHERE uid = 98340128
    AND event_date >= '2024-10-29'
ORDER BY time_stamp DESC;


/* User login events
Retrieves login data for a user starting from a specific date */

SELECT *
FROM hof_str_event_login
WHERE uid = 83675512
    AND event_date >= '2025-06-03'
ORDER BY time_stamp DESC;


/* Spins made by user
 Lists all spins by a user after a specific date, including timestamp */

SELECT time_stamp, *
FROM hof_str_event_game_spin
WHERE uid = 61053435
    AND event_date > '2025-06-25'
ORDER BY time_stamp DESC;


/* Average bet value
 Calculates the average total bet amount by a user for spins after a given date */
 
SELECT AVG(total_bet_amount)
FROM hof_ng.hof_str_event_game_spin
WHERE uid = 72356505
    AND event_date >= '2025-03-01';
