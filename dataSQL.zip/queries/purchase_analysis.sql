/* Total purchases per user
 Sum the USD value of successful purchases made by a specific user */

SELECT 
    uid, 
    SUM(amount_usd)
FROM 
    hof_ng.hof_str_event_purchase
WHERE 
    uid = 72129318
    AND tran_status_id = 1  /* status 1 means completed transaction */
GROUP BY 
    uid;


/* Tracking purchases linked to a marketing campaign)
Identify users exposed to specific inbox campaigns and rank their purchases */

WITH dormants AS (
    SELECT *
    FROM hof_ng.hof_str_inbox_envelope_history
    WHERE event_date >= '2025-04-28'
        AND origin_id LIKE '366850%'  /* marketing campaign code */
        AND origin_type_id = 80       /* inbox message type */
),

ranked_purchases AS (
    SELECT 
        *, 
        ROW_NUMBER() OVER (
            PARTITION BY uid 
            ORDER BY event_date
        ) AS row_num
    FROM 
        hof_str_event_purchase
    WHERE 
        uid IN (
            SELECT uid
            FROM dormants
        )
        AND tran_status_id = 1
        AND event_date BETWEEN '2025-04-01' AND '2025-05-09'
)

/* Final result: First 30 ranked purchases for targeted users */

SELECT 
    time_stamp, 
    event_date, 
    uid, 
    order_id, 
    amount_usd, 
    coins_amount
FROM 
    ranked_purchases
WHERE 
    row_num <= 30
ORDER BY 
    time_stamp DESC;
