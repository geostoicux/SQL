/* Claimed Facebook Gifts by a user
 This query fetches gifts of type 'FACEBOOK_GIFT' that were claimed and contain the keyword 'FREE COINS' */

SELECT *
FROM hof_str_inbox_envelope_history
WHERE uid = 112641722
    AND event_date = '2025-03-23'
    AND envelope_type = 'FACEBOOK_GIFT'
    AND state = 'CLAIMED'
    AND message LIKE '%FREE COINS%'
    AND time_stamp BETWEEN '2024-03-23 11:00:33' AND '2024-03-23 11:10:35'
ORDER BY time_stamp DESC;


/* The tracking of a feature called Stash Case.
Retrieve stash case activity for a given user on a specific event_date */

SELECT *
FROM hof_str_event_hof_stash_case
WHERE uid = 67873479
    AND event_date = '2025-06-20'
ORDER BY time_stamp DESC;
