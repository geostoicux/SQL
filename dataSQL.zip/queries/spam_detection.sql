/* Users sending repeated spam messages (possible bots)
 Detects users who sent the same or similar message multiple times */

WITH a AS (
    SELECT 
        uid,
        COUNT(message) AS message_count
    FROM 
        hof_ng.hof_str_event_hof_team_up_chat_messages
    WHERE 
        message LIKE '%hffun%1%'  /* keyword pattern to match spam */
    GROUP BY 
        uid
)

 /* Final output: Users who sent the message more than 3 times */
 
SELECT 
    uid
FROM 
    a
WHERE 
    message_count > 3;
