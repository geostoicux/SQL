/* Platform usage by spin ratio: determine which platform a user played on most */

/* First, count the number of spins per platform per user */
WITH SpinCounts AS (
    SELECT 
        uid, 
        platform_id, 
        COUNT(*) AS spins_count
    FROM 
        hof_ng.hof_str_event_game_spin
    WHERE 
        time_stamp BETWEEN '2025-02-14 00:00:00' 
        AND '2025-02-24 23:59:59'
    GROUP BY 
        uid, 
        platform_id
),

/* Then, sum all spins per user across all platforms */
TotalSpins AS (
    SELECT 
        uid, 
        SUM(spins_count) AS total_spins
    FROM 
        SpinCounts
    GROUP BY 
        uid
)

/* Finally, join both tables to calculate platform usage % and filter for dominant platform */
SELECT 
    sc.uid,
    sc.platform_id,
    sc.spins_count,
    ts.total_spins,
    (sc.spins_count * 1.0 / ts.total_spins) AS platform_percentage
FROM 
    SpinCounts sc
JOIN 
    TotalSpins ts ON sc.uid = ts.uid
WHERE 
    (sc.spins_count * 1.0 / ts.total_spins) > 0.5  /* filter for platforms where usage > 50% */
    AND sc.uid IN (266106574)                      /* focus on a specific user */
ORDER BY 
    sc.uid, 
    platform_percentage DESC;

